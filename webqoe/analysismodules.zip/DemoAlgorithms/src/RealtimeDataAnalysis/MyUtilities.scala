package RealtimeDataAnalysis

/* Spark Package */
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD

/* JSON4S Jackson Package */
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.DefaultFormats

object MyUtilities {
  
    /* General function for calculating correlation */
    /* http://www.mathsisfun.com/data/correlation.html */
    def calculateCorrelation(dataset: RDD[(Double, Double)]): Double = {
        var dblCorr: Double = 0
        // Assuming that the RDD contains: [(a1, b1) | (a2, b2) | ...]
        // First, calculate the mean of (a1, a2, ...) and (b1, b2, ...)
        dataset.persist()
        
        val totalAverage = dataset.map{case (a, b) => (a, b, 1)}.reduce((x, y) => (x._1 + y._1, x._2 + y._2, x._3 + y._3))
        val dblMeanA: Double = totalAverage._1 / totalAverage._3.toDouble
        val dblMeanB: Double = totalAverage._2 / totalAverage._3.toDouble
        
        val broadcastMeanA = dataset.sparkContext.broadcast(dblMeanA)
        val broadcastMeanB = dataset.sparkContext.broadcast(dblMeanB)
        
        // Second, calculate the correlation
        val totalCorr = dataset.map{case (a, b) => {                                      
                                        val aDiff: Double = a - broadcastMeanA.value
                                        val bDiff: Double = b - broadcastMeanB.value
                                        val axb = aDiff * bDiff
                                        val asquare = aDiff * aDiff
                                        val bsquare = bDiff * bDiff
                                        
                                        // return
                                        (axb, asquare, bsquare)
                                    }}.reduce((x, y) => {
                                                            (x._1 + y._1, x._2 + y._2, x._3 + y._3)  
                                                            })
        
        dblCorr = totalCorr._1 / scala.math.sqrt(totalCorr._2 * totalCorr._3)
        dataset.unpersist()
        
        // return
        dblCorr
    }
    
    /* http://www.dummies.com/how-to/content/how-to-interpret-a-correlation-coefficient-r.html */
    def interpreteCorrelation(dblCorr: Double): String = {
        var strRes: String = "Something wrong!"
        if (dblCorr == -1)
        {
            strRes = "Perfect negative correlation"
        }    
        else if (dblCorr > -1 && dblCorr <= -0.70)
        {
            strRes = "Strong negative correlation"        
        }
        else if (dblCorr > -0.70 && dblCorr <= -0.50)
        {
            strRes = "Moderate negative correlation"
        }
        else if (dblCorr > -0.50 && dblCorr <= -0.30)
        {
            strRes = "Weak negative correlation"
        }
        else if (dblCorr > -0.30 && dblCorr < 0.30)
        {
            strRes = "No correlation"
        }
        else if (dblCorr >= 0.30 && dblCorr < 0.50)
        {
            strRes = "Weak positive correlation"
        }
        else if (dblCorr >= 0.50 && dblCorr < 0.70)
        {
            strRes = "Moderate positive correlation"
        }
        else if (dblCorr >= 0.70 && dblCorr < 1)
        {
            strRes = "Strong positive correlation"
        }
        else if (dblCorr == 1)
        {
            strRes = "Perfect positive correlation"
        }
        
        // return
        strRes
    }
    
    def isInteger(strIn: String): Boolean = {
      
        var bl = true
      
        try
        {
            strIn.toInt
        }
        catch
        {
            case e: Exception => bl = false
        }
        
        // return
        bl
    }
    
    def isBoolean(strIn: String): Boolean = {
      
        var bl = true
      
        try
        {
            strIn.toBoolean
        }
        catch
        {
            case e: Exception => bl = false
        }
        
        // return
        bl
    }
}

