package RealtimeDataAnalysis

import util.control.Breaks._

/* Spark Package */
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD

/* JSON4S Jackson Package */
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.DefaultFormats

object MyAlgorithms {

    /* Caution: Specified property should be 'unique' and of 'int' type in EACH session */
    def calculateMean(jsonFiles: RDD[(String, String)], strProp: String): Double = {
      
       val broadcastProp = jsonFiles.sparkContext.broadcast(strProp)
       
       val eleFullLoadTime_Size = jsonFiles.map{case(filename, jsonstring) =>
                                                  {
                                                    var totalFullLoadTime: BigInt = 0
                                                    var numberFullLoadTime: Int = 0
                                                    
                                                      for (JInt(full_load_time) <- parse(jsonstring) \\ broadcastProp.value)
                                                      {
                                                          totalFullLoadTime += full_load_time
                                                          numberFullLoadTime += 1
                                                      }
                                                    
                                                    // return the result
                                                    (totalFullLoadTime, numberFullLoadTime)
                                                }}
        
        val eleReduced = eleFullLoadTime_Size.reduce{(ele1, ele2) => (ele1._1 + ele2._1, ele1._2 + ele2._2)}
        val mean: Double = (eleReduced._1.toDouble / eleReduced._2.toDouble)
        
        // return
        mean
    }
    
    /* Caution: Specified property should be 'unique' and of 'int' type in EACH session */
    def calculateMedian(jsonFiles: RDD[(String, String)], strProp: String): Double = {
        
        val broadcastProp = jsonFiles.sparkContext.broadcast(strProp)
      
        val eleFullLoadTime_Size = jsonFiles.flatMap{case(filename, jsonstring) =>
                                                  {
                                                      var arrFull_Load_Time: Array[Int] = Array()
                                                    
                                                      for (JInt(full_load_time) <- parse(jsonstring) \\ broadcastProp.value)
                                                      {
                                                          arrFull_Load_Time :+= full_load_time.toInt
                                                      }
                                                    
                                                       // return the result
                                                       arrFull_Load_Time
                                                  }}
                    
        val numberOfElements: Int = eleFullLoadTime_Size.count.toInt    // Caution! hope that the number of sessions is not too too big!
        val arrFullLoadTime: Array[Int] = eleFullLoadTime_Size.takeOrdered(numberOfElements)
        
        // for testing
        arrFullLoadTime.foreach(x => print(x + ";"))
        println("\nLength = " + arrFullLoadTime.length)
        
        var Median: Double = 0
        
        // Scala Array starts from 0!
        if (numberOfElements % 2 == 0)
        {
            val Xi_1: Int = numberOfElements/2
            val Xi: Int = Xi_1 - 1
            
            // for testing
            println("Xi = " + Xi + "; Xi_1 = " + Xi_1 + "; [Xi] = " + arrFullLoadTime(Xi) + "; [Xi_1] = " + arrFullLoadTime(Xi_1))
            
            Median = (arrFullLoadTime(Xi) + arrFullLoadTime(Xi_1)) / 2.toDouble
        }
        else
        {
            val Xi = (numberOfElements - 1) / 2
              
            // for testing
            println("Xi = " + Xi + "; [Xi] = " + arrFullLoadTime(Xi))
              
            Median = arrFullLoadTime(Xi)
        }
        
        // return
        Median
    }
    
    /* Caution: Specified property should be 'unique' and of 'int' type in EACH session */
    def calculateVariance(jsonFiles: RDD[(String, String)], dblMean: Double, strProp: String): Double = {
      
        val broadcastMean = jsonFiles.sparkContext.broadcast(dblMean);
        val broadcastProp = jsonFiles.sparkContext.broadcast(strProp)
        
        val eleFullLoadTimeMinus = jsonFiles.map{ case(filename, jsonstring) =>
                                                         {
                                                            var totalFullLoadTimeMinus: Double = 0
                                                            var numberFullLoadTime: Int = 0
                                                            
                                                            for (JInt(full_load_time) <- parse(jsonstring) \\ broadcastProp.value)
                                                            {
                                                                totalFullLoadTimeMinus += scala.math.pow(full_load_time.toDouble - broadcastMean.value, 2)
                                                                numberFullLoadTime += 1
                                                            }
                                                            
                                                            // return the result
                                                            (totalFullLoadTimeMinus, numberFullLoadTime)
                                                         }}
        
        val eleReduced = eleFullLoadTimeMinus.reduce{(ele1, ele2) => (ele1._1 + ele2._1, ele1._2 + ele2._2)}
        val dblVariance: Double = (eleReduced._1 / eleReduced._2.toDouble)
        
        // return
        dblVariance
    }
    
    /* Caution: Specified property should be 'unique' and of 'int' type in EACH session */
    def calculateTop(jsonFiles: RDD[(String, String)], intMax: Int, strProp: String): Array[Int] = {
    
        val broadcastProp = jsonFiles.sparkContext.broadcast(strProp)
        
        val eleFullLoadTime = jsonFiles.flatMap{ case(filename, jsonstring) => 
                                                            {    
                                                              var arrFullLoadTime: Array[Int] = Array()
                                                              
                                                              for (JInt(full_load_time) <- parse(jsonstring) \\ broadcastProp.value)
                                                                {
                                                                    arrFullLoadTime :+= full_load_time.toInt
                                                                }
                                                                
                                                              // return
                                                              arrFullLoadTime
                                                            }
                                                }
        
        // for testing
        eleFullLoadTime.foreach(x => print(x + " "))
        println("\nNumber of elements: " + eleFullLoadTime.count)
        
        var arrRes: Array[Int] = Array()
        if (intMax > 0)
        {
            arrRes = eleFullLoadTime.top(intMax)
        }
        
        // return
        arrRes
    }
    
    /* Caution! The specified properties are 'UNIQUE' in EACH logging session AND of 'double/int' type.
     * Each JSON File, such as "211114_155600.json", includes multiple logging sessions! */
    def calculateCorrelation(jsonFiles: RDD[(String, String)], strFirstProp: String, strSecondProp: String): Double = {
      
        if (strFirstProp == null || strFirstProp.isEmpty())
            throw new Exception("First property is null/empty")
        
        if (strSecondProp == null || strSecondProp.isEmpty())
            throw new Exception("Second property is null/empty")
      
        // first broadcast the property strings
        val broadcastFirstProp = jsonFiles.sparkContext.broadcast(strFirstProp)
        val broadcastSecondProp = jsonFiles.sparkContext.broadcast(strSecondProp)
        
        val dataset: RDD[(Double, Double)] = jsonFiles.flatMap{case (filename, jsonstring) => 
                                                                    {
                                                                        implicit val formats = DefaultFormats
                                                                        var arrFistProp: Array[Double] = Array()
                                                                        var arrSecondProp: Array[Double] = Array()
                                                                        var arrFinal: Array[(Double, Double)] = Array()
                                                                        
                                                                        /*
                                                                         * This solution cannot parse in case of "JInt"
                                                                        for (JDouble(dblFirstProp) <- parse(jsonstring) \\ broadcastFirstProp.value)
                                                                        {
                                                                            arrFistProp :+= dblFirstProp
                                                                        }
                                                                        
                                                                        for (JDouble(dblSecondProp) <- parse(jsonstring) \\ broadcastSecondProp.value)
                                                                        {
                                                                            arrSecondProp :+= dblSecondProp
                                                                        }
                                                                        */
                                                                        
                                                                        for(x <- (parse(jsonstring) \\ broadcastFirstProp.value).children)
                                                                        {
                                                                            val dblTemp: Double = x match {
                                                                                case x: JInt => x.extract[Int].toDouble
                                                                                case x: JDouble => x.extract[Double]
                                                                                case _ => throw new Exception("Invalid Data Type (Only Double/Int supported)")
                                                                            }
                                                                            
                                                                            arrFistProp :+= dblTemp
                                                                        }
                                                                        
                                                                        for(x <- (parse(jsonstring) \\ broadcastSecondProp.value).children)
                                                                        {
                                                                            val dblTemp: Double = x match {
                                                                                case x: JInt => x.extract[Int].toDouble
                                                                                case x: JDouble => x.extract[Double]
                                                                                case _ => throw new Exception("Invalid Data Type (Only Double/Int supported)")
                                                                            }
                                                                            
                                                                            arrSecondProp :+= dblTemp
                                                                        }
                                                                        
                                                                        arrFinal = for ((dbl, index) <- arrFistProp.zipWithIndex) yield (dbl, arrSecondProp(index))
                                                                        
                                                                        // return
                                                                        arrFinal
                                                                    }}
        val dblCorr = MyUtilities.calculateCorrelation(dataset)
        
        // return
        dblCorr
    }
    
    /* We suppose each json file contains multiple sessions. For each session, funcProp1 and funcProp2 are called to produce a pair of values.
     * Technically, this approach is unlimited */
    def calculateCorrelation2(jsonFiles: RDD[(String, String)], funcProp1: JValue => Double, funcProp2: JValue => Double): Double = {
      
        if (funcProp1 == null)
            throw new Exception("First Function is null")
        
        if (funcProp2 == null)
            throw new Exception("Second Function is null")
      
        // first broadcast the property functions
        val broadcastFuncProp1 = jsonFiles.sparkContext.broadcast(funcProp1)
        val broadcastFuncProp2 = jsonFiles.sparkContext.broadcast(funcProp2)
        
        val dataset: RDD[(Double, Double)] = jsonFiles.flatMap{case (filename, jsonstring) => 
                                                                    {
                                                                        implicit val formats = DefaultFormats
                                                                        var arrFinal: Array[(Double, Double)] = Array()
                                                                        
                                                                        // For each session, we invoke the pointer functions
                                                                        for (probe @ JObject(x) <- parse(jsonstring))
                                                                        {
                                                                            // Thanks to [https://stackoverflow.com/questions/21665504/check-if-an-object-has-a-field-in-json4s-lift-json]
                                                                            if ((probe \ "probeid") != JNothing)    // Its direct child must be "probeid"!
                                                                            {
                                                                                val dblFirst: Double = broadcastFuncProp1.value(probe)
                                                                                val dblSecond: Double = broadcastFuncProp2.value(probe)
                                                                                
                                                                                arrFinal :+= (dblFirst, dblSecond)
                                                                            }
                                                                        }
                                                                        
                                                                        // return
                                                                        arrFinal
                                                                    }}
        val dblCorr = MyUtilities.calculateCorrelation(dataset)
        
        // return
        dblCorr
    }
    
    def findMostContactedServers(jsonFiles: RDD[(String, String)], intTop: Int, blIncludeWebHost: Boolean): Array[(String, Int)] = {
    
        var arrServer: Array[(String, Int)] = Array()
        val broadcastIncludeWebHost = jsonFiles.sparkContext.broadcast(blIncludeWebHost)
        
        val rddServerList = jsonFiles.flatMap{case(filename, jsonstring) => 
                                                    {
                                                        implicit val formats = DefaultFormats
                                                        var arrUrl: Array[String] = Array()
                                                        
                                                        // For each session, we find the servers contacted
                                                        for (probe @ JObject(x) <- parse(jsonstring))
                                                        {
                                                            // we find the session object (a json files contains multiple logging sessions)
                                                            if ((probe \ "probeid") != JNothing)    // Its direct child must be "probeid"!
                                                            {
                                                                var strSessionUrl: String = ""
                                                                if (broadcastIncludeWebHost == false)
                                                                {
                                                                    // special case in logging session, [http://www.google.com] should be the same as [http://www.google.com/]
                                                                    strSessionUrl = (probe \ "session_url").extract[String].trim()
                                                                    if (strSessionUrl.endsWith("/"))
                                                                        strSessionUrl = strSessionUrl.substring(0, strSessionUrl.length() - 1)
                                                                }
                                                                
                                                                for(JString(x) <- probe \\ "base_url")
                                                                {
                                                                    var strNew: String = x.trim()
                                                                    if (strNew.endsWith("/"))
                                                                        strNew = strNew.substring(0, strNew.length() - 1)
                                                                    
                                                                    if (broadcastIncludeWebHost == true || strSessionUrl != strNew)
                                                                        arrUrl :+= strNew
                                                                }
                                                            }
                                                        }
                                                        
                                                        // return
                                                        arrUrl
                                                    }
        }
        
        val rddServerListReduced = rddServerList.map(x => (x, 1)).reduceByKey{case(num1, num2) => num1 + num2}
        
        if (intTop > 0)
        {
            // Thanks to [http://apache-spark-user-list.1001560.n3.nabble.com/RDD-top-method-exception-td3987.html]
            arrServer = rddServerListReduced.top(intTop)(Ordering.by(f => f._2))
        }
        
        // return
        arrServer
    }
    
    def findMostSourceCommonPaths_SingleProbe(jsonFiles: RDD[(String, String)], intProbeId: Int, intMinEndPoint: Int): (String, Int, Int) = {
        
        if (intProbeId <= 0)
            throw new Exception("Invalid probe id")
        
        if (intMinEndPoint < 1)
            throw new Exception("Invalid minimum end points")
      
        val (pathList, numOfPathFound, umOfProcessedSession, numofTotalSession) = findPaths(jsonFiles, intProbeId)
        
        // for debugging
        pathList.foreach(println)
        
        val (mostCommPath, sharedBy) = filterMostCommonPaths(pathList, intMinEndPoint)
        
        // for visual presentation
        val strNewPath = mostCommPath.substring(0, mostCommPath.length() - 1).replaceAll(";", " -> ")
        
        // return
        (strNewPath, sharedBy, numOfPathFound)
    }
    
    def findMostDestCommonPaths_MultiProbes(jsonFiles: RDD[(String, String)], intMinEndPoint: Int): (String, Int, Int) = {
    
        if (intMinEndPoint < 1)
            throw new Exception("Invalid minimum end points")
        
        val (pathList, numOfPathFound, umOfProcessedSession, numofTotalSession) = findPaths(jsonFiles, 0)   // expect: umOfProcessedSession = numofTotalSession
    
        // we change the pathlist a little bit -> reverse each path
        val newPathList = pathList.map(strPath => {
                                                        val strTemp = strPath.substring(0, strPath.length() - 1)        // remove the last ";"
                                                        val arrHops = strTemp.split(";")
                                                        val strBuilder = new StringBuilder
                                                        
                                                        for ((hop, index) <- arrHops.zipWithIndex)
                                                        {
                                                            strBuilder.insert(0, arrHops(index) + ";")      // top -> tail and vice versa...
                                                        }
                                                        
                                                        // return
                                                        strBuilder.toString()
                                                    })

        // for debugging
        newPathList.foreach(println)
                                                    
        val (mostCommPath, sharedBy) = filterMostCommonPaths(newPathList, intMinEndPoint)
        
        // for visual presentation
        val strNewPath = mostCommPath.substring(0, mostCommPath.length() - 1).replaceAll(";", " <- ")
                                                    
        // return
        (strNewPath, sharedBy, numOfPathFound)
    }
    
    /* ********************************************************************************************************************* */
    
    /* This method is used to find all the paths in all json files. intProbeId, if different than 0, is used to filter. */
    //protected def findPaths(jsonFiles: RDD[(String, String)], intProbeId: Int): (RDD[String], numOfPathFound: Int, umOfProcessedSession: Int, numofTotalSession: Int) = {
    protected def findPaths(jsonFiles: RDD[(String, String)], intProbeId: Int): (RDD[String], Int, Int, Int) = {
        if (intProbeId < 0)
            throw new Exception("Invalid probe id")
      
        val broadcastProbeId = jsonFiles.sparkContext.broadcast(intProbeId)     // at this point, we don't care if it is 0 or not...
        
        // Spark accumulator - for statistics
        val numOfPathFound = jsonFiles.sparkContext.accumulator(0)
        val umOfProcessedSession = jsonFiles.sparkContext.accumulator(0)
        val numofTotalSession = jsonFiles.sparkContext.accumulator(0)
        
        val pathList = jsonFiles.map{case(filename, jsonstring) => {
                                                        implicit val formats = DefaultFormats
                                                        
                                                        // if there is not probe found, array has length 0
                                                        var arrPaths: Array[String] = Array()
                                                        
                                                        for (probe @ JObject(x) <- parse(jsonstring))
                                                        {
                                                            // we find the session object (a json files contains multiple logging sessions)
                                                            val jso = (probe \ "probeid")       // symbol "\" -> get direct child
                                                            if (jso != JNothing)
                                                            {
                                                                numofTotalSession += 1          // another session found!
                                                                
                                                                // if the probeid = 0, we don't care about discriminating against other probeids
                                                                if (broadcastProbeId.value == 0 || jso.extract[Int] == broadcastProbeId.value)
                                                                {
                                                                    umOfProcessedSession += 1   // another filtered session found!
                                                                  
                                                                    for (JString(strChildJson) <- probe \\ "trace") // Each trace is a "path" for the specified probe in a session
                                                                    {
                                                                        val childJson = parse(strChildJson)
                                                                        val strBuilder = new StringBuilder
                                                                        
                                                                        for (JString(ip) <- childJson \\ "ip_addr") // every ip is a "hop" in the current path
                                                                        {
                                                                            // Thanks to [https://stackoverflow.com/questions/11637372/why-no-stringbuilder-string-in-scala]
                                                                            strBuilder ++= ip + ";"
                                                                        }
                                                                        
                                                                        arrPaths :+= strBuilder.toString() // there is ";" at the last character!
                                                                        
                                                                        // keep track
                                                                        numOfPathFound += 1
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        // return
                                                        arrPaths
                                                    }}
                                                        .filter(arr => arr.length > 0)      // if specified probeid != 0, there is a possibility that a json file does not contain any session of the specified probe; if specified probeid = 0, it's almost impossible to have array.length = 0, but be careful anyway.
                                                        .flatMap(arr => arr)                // now, its element of RDD is a path typed of string
    
        
        // force Spark to do computation (not LAZY). If we don't do this now, numOfPathFound, umOfProcessedSession, numofTotalSession become meaningless
        pathList.persist()  // "persist" flag must be set before calling any action
        pathList.count()    // force to do computation
                                                        
        // return
        (pathList, numOfPathFound.value, umOfProcessedSession.value, numofTotalSession.value)
    }
    
    /* This method is used to filter out paths that satisfy some criteria, such as: minendpoint */
    protected def filterMostCommonPaths(pathList: RDD[String], intMinEndPoint: Int): (String, Int) = {
    
        if (intMinEndPoint < 1)
            throw new Exception("Invalid number of minimum end points")
      
        pathList.persist()  // we would probably use this RDD again and again
        
        var mostCommonPath: (String, Int) = ("", 0)
        var blContinue: Boolean = true
        var intTempEndPoint = intMinEndPoint - 1        // for convenience in increasing
        var blUnbelievableCaseHappened: Boolean = false
        var arrTemp: Array[(String, Int)] = null
        
        do
        {
            intTempEndPoint += 1
            val broadcastMinEndPoint = pathList.sparkContext.broadcast(intTempEndPoint)
            
            // this array is supposed to have one element ("the most")
            arrTemp = pathList.map(strPath => {   // chop the path from source to intTempEndPoint hops
                                        var strRes = ""
                                        var currPos = 0
                                        var currTime = 0
                                        
                                        // Thanks to [http://alvinalexander.com/scala/scala-break-continue-examples-breakable]
                                        breakable{
                                            do
                                            {
                                                currPos = strPath.indexOf(";", currPos+1)
                                                if (currPos < 0)                                // this path is smaller than expected (intTempEndPoint) -> discard it!
                                                    scala.util.control.Breaks.break()
                                                
                                                currTime += 1
                                                if (currTime == broadcastMinEndPoint.value)
                                                    scala.util.control.Breaks.break()
                                            }
                                            while(true)
                                        }
                                        
                                        if (currPos >= 0)
                                            strRes = strPath.substring(0, currPos + 1)  // there is a ";" at the end -> for consistency!
                                          
                                        // return
                                        strRes
                                    })
                                        .filter(strPath => strPath.length() > 0)        // filter out discarded path (length 0)
                                        .map(strPath => (strPath, 1))
                                        .reduceByKey{case (x,y) => x + y}
                                        .top(1)(Ordering.by(f => f._2))                 // Caution! We may have 2 or more different same-hop paths shared by equal amounts of "traces" 
            
            if (mostCommonPath._2 == 0)
            {
                mostCommonPath = arrTemp(0)                 // initialization
                blContinue = true
            }
            else if (mostCommonPath._2 == arrTemp(0)._2)
            {
                mostCommonPath = arrTemp(0)                 // choose the longer path that has the same number of "traces" overlapping this path
                blContinue = true
            }
            else if (mostCommonPath._2 > arrTemp(0)._2)
            {
                blContinue = false                          // increasing the hop number results in less traces sharing the same common path
            }
            else    // mostCommonPath._2 < arrTemp(0)._2 --> cannot be this case!!!
            {
                blUnbelievableCaseHappened = true
                blContinue = false
            }
            
        }
        while (blContinue)
        
        // important!
        pathList.unpersist()
        
        if (blUnbelievableCaseHappened)
            throw new Exception("Something wrong!")
        
        // return
        (arrTemp(0)._1, arrTemp(0)._2)
    }
}


