package RealtimeDataAnalysis

/* Spark Package */
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD

/* Logging Package */
import org.apache.log4j.Logger
import org.apache.log4j.Level

/* JSON4S Jackson Package */
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.DefaultFormats


object DemoMain {
    def main(args: Array[String]) {
        println("*** PROGRAM STARTED ***")
        
        // suppress the annoying loggings from Spark (https://stackoverflow.com/questions/25193488/how-to-turn-off-info-logging-in-pyspark)
        Logger.getLogger("org").setLevel(Level.OFF)
        Logger.getLogger("akka").setLevel(Level.OFF)
  
        try
        {
            // check basic input requirements
            val (strPath, strFuncName, arg3, arg4) = validateInputs(args)
          
            // path to JSON Files, could be HDFS or local file system
            //val strPath = "d:/MyGit/zTemp/mplane/2015/1/*/*";
            
            // initialize spark: 4 worker threads, application name in cluster "DemoAlgorithms"
            val cfg = new SparkConf().setMaster("local[4]").setAppName("DemoAlgorithms")
            val sc = new SparkContext(cfg)
            
            // mark the starttime
            val startTime = System.currentTimeMillis()
            
            // read the JSON files
            val jsonFiles = sc.wholeTextFiles(strPath)
            jsonFiles.persist()
            
            // check number of files read
            println()
            val fileCount = jsonFiles.count()
            if (fileCount == 0)
                throw new Exception("Json Files: No file found")
            
            println(fileCount + " (json files)")
            jsonFiles.foreach{case (x, y) => println(x)}
            println()
            
            // check function name to divert
            if (strFuncName.compareToIgnoreCase("calculateMean") == 0)
            {
                val dblMean = MyAlgorithms.calculateMean(jsonFiles, arg3)
                println("Mean (" + arg3 + ") = " + dblMean)
            }
            else if (strFuncName.compareToIgnoreCase("calculateMedian") == 0)
            {
                val dblMedian = MyAlgorithms.calculateMedian(jsonFiles, arg3)
                println("Median (" + arg3 + ") = " + dblMedian)
            }
            else if (strFuncName.compareToIgnoreCase("calculateVariance") == 0)
            {
                val dblMean = MyAlgorithms.calculateMean(jsonFiles, arg3)
                val dblVariance = MyAlgorithms.calculateVariance(jsonFiles, dblMean, arg3)
                println("Variance (" + arg3 + ") = " + dblVariance)
            }
            else if (strFuncName.compareToIgnoreCase("calculateTop") == 0)
            {
                val arrTop: Array[Int] = MyAlgorithms.calculateTop(jsonFiles, arg4.toInt, arg3)
                println("Top " + arg4 + " (" + arg3 + "): " + arrTop.mkString(";"))
            }
            else if (strFuncName.compareToIgnoreCase("calculateCorrelation") == 0)
            {
                var dblCorr: Double = 0
                
                // special cases because these properties are not unique for each session -> process case-by-case
                if (arg3 == "full_load_time" && arg4 == "sum_syn")
                {
                    dblCorr = MyAlgorithms.calculateCorrelation2(jsonFiles, sessionJso1 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso1 \ arg3).extract[Int].toDouble
                                                                                        }, 
                                                                         sessionJso2 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            var intTotal: Int = 0
                                                                                            
                                                                                            for(JInt(x) <- (sessionJso2 \\ arg4))
                                                                                            {
                                                                                                intTotal += x.toInt
                                                                                            }
                                                                                            
                                                                                            // return
                                                                                            intTotal.toDouble
                                                                         })
                }
                else if (arg3 == "full_load_time" && arg4 == "sum_http")
                {
                    dblCorr = MyAlgorithms.calculateCorrelation2(jsonFiles, sessionJso1 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso1 \ arg3).extract[Int].toDouble
                                                                                        }, 
                                                                         sessionJso2 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            var intTotal: Int = 0
                                                                                            
                                                                                            for(JInt(x) <- (sessionJso2 \\ arg4))
                                                                                            {
                                                                                                intTotal += x.toInt
                                                                                            }
                                                                                            
                                                                                            // return
                                                                                            intTotal.toDouble
                                                                         })
                }
                else
                {
                    dblCorr = MyAlgorithms.calculateCorrelation(jsonFiles, arg3, arg4)
                }
                
                println("Correlation (" + arg3 + ", " + arg4 + ") = " + dblCorr + "\n--> " + MyUtilities.interpreteCorrelation(dblCorr))
            }
            else if (strFuncName.compareToIgnoreCase("findMostContactedServers") == 0)
            {
                val arrMostContacted: Array[(String, Int)] = MyAlgorithms.findMostContactedServers(jsonFiles, arg3.toInt, arg4.toBoolean)
                println("Top " + arg3 + " most contacted servers (" + (if (arg4.toBoolean) "" else "NOT ") + "include web host):")
                arrMostContacted.foreach(println)
            }
            else if (strFuncName.compareToIgnoreCase("findMostSourceCommonPaths_SingleProbe") == 0)
            {
                val mostCommPath: (String, Int, Int) = MyAlgorithms.findMostSourceCommonPaths_SingleProbe(jsonFiles, arg3.toInt, arg4.toInt)
                
                println("ProbeId: " + arg3)
                
                println("Most Common Path From Source (Minimum Hops: " + arg4 + "): " + mostCommPath._1)
                println("Shared by: " + mostCommPath._2 + " traces (" + math.round((mostCommPath._2/mostCommPath._3.toDouble)*100) + "%)")
                println("Total: " + mostCommPath._3 + " traces")
            }
            else if (strFuncName.compareToIgnoreCase("findMostDestCommonPaths_MultiProbes") == 0)
            {
                val mostCommonDestPath = MyAlgorithms.findMostDestCommonPaths_MultiProbes(jsonFiles, arg3.toInt)
                
                println("Most Common Path To Destination (Minimum Hops: " + arg3 + "): " + mostCommonDestPath._1)
                println("Shared by: " + mostCommonDestPath._2 + " traces (" + math.round((mostCommonDestPath._2 / mostCommonDestPath._3.toDouble)*100) + "%)")
                println("Total: " + mostCommonDestPath._3 + " traces")
            }
            else
                throw new Exception("Function Name: Unknown")
            
            println("\n*** ALL INSTRUCTIONS FINISHED ***")
            println("Time Cost (User's Code): " + (System.currentTimeMillis() - startTime) + " ms")
        }
        catch
        {
            case e: Exception => println("*** PROGRAM EXCEPTION: " + e.getMessage() + " ***");
        }
        finally
        {
            println("*** PROGRAM ENDED ***")
        }
    }
    
    protected def validateInputs(args: Array[String]): (String, String, String, String) = {
        
        var strArg3 = ""
        var strArg4 = ""
    
        val UNNECESSESARY_ARG = "Inputs: Some unnecessary"
          
        if (args == null || args.length == 0)
            throw new Exception("Inputs: Missing")
        
        if (args.length < 2)
            throw new Exception("BASIC Inputs: Missing [Json File Path] [FunctionName]")
        
        val strPath = args(0)
        val strFuncName = args(1)
        
        // <string>
        if (strFuncName.compareToIgnoreCase("calculateMean") == 0 || 
            strFuncName.compareToIgnoreCase("calculateMedian") == 0 ||
            strFuncName.compareToIgnoreCase("calculateVariance") == 0)
        {
            if (args.length == 3)
                strArg3 = args(2)
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        // <string> <number>
        else if (strFuncName.compareToIgnoreCase("calculateTop") == 0)
        {
            if (args.length == 4)
            {   
                strArg3 = args(2)
                strArg4 = args(3)
                if (MyUtilities.isInteger(strArg4) == false)
                    throw new Exception("Inputs: Argument 4 not a integer")
            }
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        // <string> <string>
        else if (strFuncName.compareToIgnoreCase("calculateCorrelation") == 0)
        {
            if (args.length == 4)
            {   
                strArg3 = args(2)
                strArg4 = args(3)
            }
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        // <number> <boolean>
        else if (strFuncName.compareToIgnoreCase("findMostContactedServers") == 0)
        {
            if (args.length == 4)
            {   
                strArg3 = args(2)
                strArg4 = args(3)
                if (MyUtilities.isInteger(strArg3) == false)
                    throw new Exception("Inputs: Argument 3 not a integer")
                if (MyUtilities.isBoolean(strArg4) == false)
                    throw new Exception("Inputs: Argument 4 not a boolean")
            }
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        // <number> <number>
        else if (strFuncName.compareToIgnoreCase("findMostSourceCommonPaths_SingleProbe") == 0)
        {
            if (args.length == 4)
            {   
                strArg3 = args(2)
                strArg4 = args(3)
                if (MyUtilities.isInteger(strArg3) == false)
                    throw new Exception("Inputs: Argument 3 not a integer")
                if (MyUtilities.isInteger(strArg4) == false)
                    throw new Exception("Inputs: Argument 4 not a integer")
            }
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        // <number>
        else if (strFuncName.compareToIgnoreCase("findMostDestCommonPaths_MultiProbes") == 0)
        {
            if (args.length == 3)
            {   
                strArg3 = args(2)
                if (MyUtilities.isInteger(strArg3) == false)
                    throw new Exception("Inputs: Argument 3 not a integer")
            }
            else
                throw new Exception(UNNECESSESARY_ARG)
        }
        else
            throw new Exception("Function Name: Unknown")
        
        (strPath, strFuncName, strArg3, strArg4)
    }
}

/*
            //Algorithm 1a
            val dblMean = MyAlgorithms.calculateMean(jsonFiles, "full_load_time")
            println("Mean = " + dblMean)
            */
            
            /*
            val dblMedian = MyAlgorithms.calculateMedian(jsonFiles, "full_load_time")
            println("Median = " + dblMedian)
            */
            
            /*
            val dblVariance = MyAlgorithms.calculateVariance(jsonFiles, dblMean, "full_load_time")
            println("Variance = " + dblVariance)
            */
            
            /*
            val arrTop: Array[Int] = MyAlgorithms.calculateTop(jsonFiles, 5, "full_load_time")
            println("Top 5 is: " + arrTop.mkString(";"))
            */
            
            /*
            val myTestRDDForCorrelation: RDD[(Double, Double)] = sc.parallelize(List((14.2, 215), (16.4, 325), (11.9, 185), 
                                                                (15.2, 332), (18.5, 406), (22.1, 522), 
                                                                (19.4, 412), (25.1, 614), (23.4, 544), 
                                                                (18.1, 421), (22.6, 445), (17.2, 408)))
            val dblTestCorr = MyUtilities.calculateCorrelation(myTestRDDForCorrelation)
            println("dblTestCorr = " + dblTestCorr) // should be 0.9575
            */
            
            /*
            val dblCorr = MyAlgorithms.calculateCorrelation(jsonFiles, "full_load_time", "page_dim")
            println("dblCorr = " + dblCorr + "\n--> " + MyUtilities.interpreteCorrelation(dblCorr))
            */
            
            /*
            val dblCorr2 = MyAlgorithms.calculateCorrelation2(jsonFiles, sessionJso1 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso1 \ "full_load_time").extract[Int].toDouble
                                                                                        }, 
                                                                         sessionJso2 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso2 \ "page_dim").extract[Int].toDouble
                                                                         })
            println("dblCorr2 = " + dblCorr2 + "\n--> " + MyUtilities.interpreteCorrelation(dblCorr2))
            */
            
            /*
            val dblCorr3 = MyAlgorithms.calculateCorrelation2(jsonFiles, sessionJso1 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso1 \ "full_load_time").extract[Int].toDouble
                                                                                        }, 
                                                                         sessionJso2 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            var intTotal: Int = 0
                                                                                            
                                                                                            for(JInt(x) <- (sessionJso2 \\ "sum_syn"))
                                                                                            {
                                                                                                intTotal += x.toInt
                                                                                            }
                                                                                            
                                                                                            // return
                                                                                            intTotal.toDouble
                                                                         })
            println("dblCorr3 = " + dblCorr3 + "\n--> " + MyUtilities.interpreteCorrelation(dblCorr3))
            */
            
            /*
            val dblCorr4 = MyAlgorithms.calculateCorrelation2(jsonFiles, sessionJso1 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            (sessionJso1 \ "full_load_time").extract[Int].toDouble
                                                                                        }, 
                                                                         sessionJso2 => {
                                                                                            implicit val formats = DefaultFormats
                                                                                            var intTotal: Int = 0
                                                                                            
                                                                                            for(JInt(x) <- (sessionJso2 \\ "sum_http"))
                                                                                            {
                                                                                                intTotal += x.toInt
                                                                                            }
                                                                                            
                                                                                            // return
                                                                                            intTotal.toDouble
                                                                         })
            println("dblCorr4 = " + dblCorr4 + "\n--> " + MyUtilities.interpreteCorrelation(dblCorr4))
            */
            
            /*
            val arrMostContacted: Array[(String, Int)] = MyAlgorithms.findMostContactedServers(jsonFiles, 100, true)
            println("Most contacted servers:")
            arrMostContacted.foreach(println)
            */
            
            /*
            val probeid: Int = 410480544
            val minHop: Int = 5
            val mostCommPath: (String, Int, Int) = MyAlgorithms.findMostSourceCommonPaths_SingleProbe(jsonFiles, probeid, minHop)
            
            println("ProbeId: " + probeid)
            println("MinHop: " + minHop)
            
            println("Most Common Path From Source: " + mostCommPath._1)
            println("Shared by: " + mostCommPath._2 + " traces (" + math.round((mostCommPath._2/mostCommPath._3.toDouble)*100) + "%)")
            println("Total number of traces: " + mostCommPath._3)
            */
            
            /*
            val minHop: Int = 22
            val mostCommonDestPath = MyAlgorithms.findMostDestCommonPaths_MultiProbes(jsonFiles, minHop)
            
            println("MinHop: " + minHop)
            
            println("Most Common Path To Destination: " + mostCommonDestPath._1)
            println("Shared by: " + mostCommonDestPath._2 + " traces (" + math.round((mostCommonDestPath._2 / mostCommonDestPath._3.toDouble)*100) + "%)")
            println("Total number of traces: " + mostCommonDestPath._3)
            */

